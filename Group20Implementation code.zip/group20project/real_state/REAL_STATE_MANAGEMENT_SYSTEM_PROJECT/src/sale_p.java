
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author admin
 */
public class sale_p {

    private int id;
    private int propertyId;
    private int clientId;
    private String finalPrice;
    private String sellingDate;
    
    public sale_p(){}
    
    public sale_p(int ID, int PROPERTY_ID, int CLIENT_ID, String FINAL_PRICE, String SELLING_DATE)
    {
        this.id = ID;
        this.propertyId = PROPERTY_ID;
        this.clientId = CLIENT_ID;
        this.finalPrice = FINAL_PRICE;
        this.sellingDate = SELLING_DATE;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getFinalPrice() {
        return finalPrice;
    }

    public void setFinalPrice(String finalPrice) {
        this.finalPrice = finalPrice;
    }

    public String getSellingDate() {
        return sellingDate;
    }

    public void setSellingDate(String sellingDate) {
        this.sellingDate = sellingDate;
    }
    
    
    // create a function to add a new sale
    public boolean addNewSale(sale_p sale)
    {
        PreparedStatement ps;
       
        String addQuery = "INSERT INTO `sale`(`property_id`, `client_id`, `final_price`, `sale_date`) VALUES (?,?,?,?)";
       
        try {
            ps = conn.getTheConnection().prepareStatement(addQuery);
            ps.setInt(1, sale.getPropertyId());
            ps.setInt(2, sale.getClientId());
            ps.setString(3, sale.getFinalPrice());
            ps.setString(4, sale.getSellingDate());
            
            return (ps.executeUpdate() > 0);
            
        } catch (SQLException ex) {
            Logger.getLogger(sale_p.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
    }
    
    
    // create a function to edit the selected sale data
    public boolean editSale(sale_p sale)
    {
        PreparedStatement ps;
        
        String editQuery = "UPDATE `sale` SET `property_id`=?,`client_id`=?,`final_price`=?,`sale_date`=? WHERE `id`=?";
        
        try {
            ps = conn.getTheConnection().prepareStatement(editQuery);
            ps.setInt(1, sale.getPropertyId());
            ps.setInt(2, sale.getClientId());
            ps.setString(3, sale.getFinalPrice());
            ps.setString(4, sale.getSellingDate());
            ps.setInt(5, sale.getId());
            
            return (ps.executeUpdate() > 0);
            
        } catch (SQLException ex) {
            Logger.getLogger(sale_p.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    
    // create a function to delete the selected sale
    public boolean deleteSale(int saleId)
    {
        PreparedStatement ps;
        
        String deleteQuery = "DELETE FROM `sale` WHERE `id`=?";
        
        try {
            ps = conn.getTheConnection().prepareStatement(deleteQuery);
            
            ps.setInt(1, saleId);
            
            return (ps.executeUpdate() > 0);
            
        } catch (SQLException ex) {
            Logger.getLogger(sale_p.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } 
    }
    
 
    // create a unction to return an arraylist of sales
    public ArrayList<sale_p> salesList()
    {
        ArrayList<sale_p> list = new ArrayList<>();
        
        Statement st;
        ResultSet rs;
        
        String selectQuery = "SELECT * FROM `sale`";
        
        try {
            
            st = conn.getTheConnection().createStatement();
            rs = st.executeQuery(selectQuery);
            
            sale_p sale;
            
            while (rs.next()) {
                
                sale = new sale_p(rs.getInt(1),
                                    rs.getInt(2), 
                                    rs.getInt(3),
                                    rs.getString(4), 
                                    rs.getString(5));
                
                list.add(sale);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(sale_p.class.getName()).log(Level.SEVERE, null, ex);
        }

        return list;
    }
    
    
    
}
